package com.grownited;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApprisalTrackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
